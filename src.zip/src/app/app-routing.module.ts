import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashbordComponent } from './component/dashbord/dashbord.component';
const routes: Routes = [
  {path: '', redirectTo:'file-upload', pathMatch:'full'},
  {path:'dashbord',component:DashbordComponent},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
