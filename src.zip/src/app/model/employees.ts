export interface Employees {
    
    id:string,
    email: string,
    name:string
}
